
for i in range(2,5):
    print(i)